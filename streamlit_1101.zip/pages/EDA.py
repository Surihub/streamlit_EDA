import streamlit as st

st.title("EDA")
st.write("그래프 제작 준비중입니다.")